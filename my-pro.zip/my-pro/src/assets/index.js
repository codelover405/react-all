import facebook from "./facebook.svg";
import instagram from "./instagram.svg";
import linkedin from "./linkedin.svg";
import twitter from "./twitter.svg";
import menu from "./menu.svg";
import close from "./close.svg";
import logo from "./logo.jpg";
import nav_menu from "./nav_menu.svg";
import nav_close from "./nav_close.svg";
import logo1 from "./logo.svg";
import cart from "./cart.svg";
import one from "./1.jpg";
import two from "./2.jpg";
import three from "./3.jpg";

export {
  facebook,
  instagram,
  linkedin,
  twitter,
  close,
  menu,
  logo,
  nav_close,
  nav_menu,
  logo1,
  cart,
  one,
  two,
  three,
};
