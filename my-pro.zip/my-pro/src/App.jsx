import { useState } from "react";
import "./App.css";
import { Route, Router, Routes } from "react-router-dom";
import Signup from "./components/authentication/signup";
import Header from "./components/Header";
import Footer from "./components/Footer";
import Layout from "./components/layout";
import Login from "./components/authentication/login";
import About from "./components/About";
import Page404 from "./components/404Page";
// import { Header, Footer, Media, Signup, Login } from "./components/index";

function App() {
  return (
    <div>
      <Routes>
        <Route path="/" element={<Signup />} />
        <Route path="/login" element={<Login />} />
        <Route exact path="/home" element={<Layout />} />
        <Route path="*" element={<Page404 />} />
        {/* other */}
        <Route path="/about" element={<About />} />
        {/* <Route path="/" element={<Layout />} /> */}
        {/* <Route path="/home" element={<Layout />} /> */}

        <Route element={<Layout />}>
          <Route path="/signup" element={<Signup />} />
          <Route path="/login" element={<Login />} />
        </Route>
      </Routes>
    </div>
  );
}

export default App;
