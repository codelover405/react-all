import Header from "./Header";
import Footer from "./Footer";
import Hero from "./small/Hero";
import Carousels from "./small/Carousel";
import Media from "./small/Media";
import Login from "./authentication/login";
import Signup from "./authentication/signup";

export { Header, Footer, Hero, Carousels, Media, Login, Signup };
